<script lang="ts" module>
	// sample data
	const data = {
	  versions: ["1.0.1", "1.1.0-alpha", "2.0.0-beta1"],
	  navMain: [
		{
		  title: "Discover",
		  url: "/discover",
		  items: [
			{
			  title: "Spaces",
			  url: "/spaces",
			  isActive: false,
			},
			{
			  title: "Agents",
			  url: "/agents",
			  isActive: false,
			},
			{
			  title: "Characters",
			  url: "/characters",
			  isActive: false,
			},
		  ],
		},
		{
		  title: "Chats",
		  url: "/chats",
		  items: [],
		},
		{
		  title: "Dashboard",
		  url: "/dashboard",
		  items: [],
		},
	  ],
	};
  </script>

<script lang="ts">
	import "../app.css";
	import { Toaster } from "svelte-sonner";
	import * as Sidebar from "$lib/components/ui/sidebar/index.js";
	import { page } from "$app/stores";
	import MenuSwitcher from "$lib/components/ui/menu-switcher/menu-switcher.svelte";
	// import logo from "../assests/logo.jpg";
	import type { ComponentProps } from "svelte";
	import Separator from "$lib/components/ui/separator/separator.svelte";
	import { goto } from "$app/navigation";
  
	function handleNavigate(endPoint: string): void {
	  if (endPoint) {
		goto(endPoint).catch((err) => console.error("Navigation error:", err));
	  }
	}
  
	const tabs = [
	  { label: "Discover", endpoint: "/discover", hasBorder: false },
	  { label: "Spaces", endpoint: "/spaces", hasBorder: true },
	  { label: "Agents", endpoint: "/agents", hasBorder: true },
	  { label: "Characters", endpoint: "/characters", hasBorder: true },
	  { label: "Chats", endpoint: "/chats", hasBorder: false },
	  { label: "Dashboard", endpoint: "/dashboard", hasBorder: false },
	];
	
	import type { SvelteComponent } from "svelte";
	
	let ref: SvelteComponent | null = null;
	let restProps: Partial<ComponentProps<typeof Sidebar.Root>> = {};
  </script>

{#if $page.url.pathname !== "/"}
    <Sidebar.Provider>
      <Sidebar.Root {...restProps} bind:this={ref}>
        <Sidebar.Header>
          <!-- <img src={logo} alt="logo"> -->
        </Sidebar.Header>
        <Sidebar.Content>
          {#each data.navMain as group (group.title)}
            <Sidebar.Group>
              <Sidebar.GroupLabel>{group.title}</Sidebar.GroupLabel>
              <Sidebar.GroupContent>
                <Sidebar.Menu>
                  {#each group.items as item (item.title)}
                    <Sidebar.MenuItem>
                      <Sidebar.MenuButton isActive={item.isActive}>
                        <a href={item.url}>{item.title}</a>
                      </Sidebar.MenuButton>
                    </Sidebar.MenuItem>
                  {/each}
                </Sidebar.Menu>
              </Sidebar.GroupContent>
            </Sidebar.Group>
          {/each}
        </Sidebar.Content>
        <Sidebar.Footer>
          <MenuSwitcher versions={data.versions} defaultVersion={data.versions[0]} />
        </Sidebar.Footer>
        <Sidebar.Rail />
      </Sidebar.Root>
      <Sidebar.Inset>
        <header class="flex h-16 shrink-0 items-center gap-2 border-b px-4">
          <Sidebar.Trigger class="-ml-1" />
          <Separator orientation="vertical" class="mr-2 h-4" />
        </header>
        <slot />
      </Sidebar.Inset>
    </Sidebar.Provider>
{:else}
    <slot />
{/if}
